package net.codejava.SpringBootWebAppExample;
 
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
 
@SpringBootApplication
public class SpringBootWebAppExampleApplication {
 
    public static void main(String[] args) {
        SpringApplication.run(SpringBootWebAppExampleApplication.class, args);
    }
}